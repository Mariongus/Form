/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  CheckCircle2, 
  Paintbrush, 
  Droplets, 
  Layers, 
  ShieldCheck, 
  Trash2, 
  HardHat, 
  Wrench, 
  Menu,
  ChevronRight,
  ClipboardCheck,
  Send
} from 'lucide-react';

const SECTIONS: FormSection[] = [
  {
    id: "paint",
    googleEntryId: "entry.1184941150",
    title: "Pintura y Color Base",
    icon: Paintbrush,
    options: [
      "Base color (colores sólidos, metálicos, perlados, camaleón, candy)",
      "Pintura acrílica",
      "Esmalte automotriz",
      "Pintura poliuretano",
      "Colores preparados / igualados"
    ]
  },
  {
    id: "varnish",
    googleEntryId: "entry.354374968",
    title: "Barnices y Lacas",
    icon: Droplets,
    options: [
      "Barniz alto brillo",
      "Barniz mate / satinado",
      "Laca automotriz",
      "Barniz rápido secado",
      "Barniz alto sólido",
      "Primers / aparejos / imprimaciones (para metal, plástico, fibra)"
    ]
  },
  {
    id: "primers",
    googleEntryId: "entry.337017811",
    title: "Primers y Selladores",
    icon: Layers,
    options: [
      "Primer gris / blanco / negro",
      "Primer relleno",
      "Primer epóxico",
      "Sellador",
      "Wash primer"
    ]
  },
  {
    id: "fillers",
    googleEntryId: "entry.407455303",
    title: "Masillas y Rellenos",
    icon: Layers,
    options: [
      "Masilla liviana",
      "Masilla pesada",
      "Masilla plástica",
      "Masilla con fibra",
      "Masilla poliéster"
    ]
  },
  {
    id: "sanding",
    googleEntryId: "entry.915091159",
    title: "Lijas",
    icon: Menu,
    options: [
      "Lija al agua",
      "Lija seca",
      "Lija gruesa / media / fina",
      "Discos de lija"
    ]
  },
  {
    id: "thinners",
    googleEntryId: "entry.782691391",
    title: "Thinners y Solventes",
    icon: Droplets,
    options: [
      "Thinner acrílico",
      "Thinner poliuretano",
      "Reductor",
      "Solvente",
      "Desengrasante"
    ]
  },
  {
    id: "catalysts",
    googleEntryId: "entry.37855143",
    title: "Catalizadores y Endurecedores",
    icon: Droplets,
    options: [
      "Catalizador para barniz",
      "Catalizador para pintura",
      "Endurecedor"
    ]
  },
  {
    id: "polishing",
    googleEntryId: "entry.384733118",
    title: "Pulido y Brillado",
    icon: Droplets,
    options: [
      "Rubbing compuesto",
      "Pulimento",
      "Cera",
      "Hand glaze",
      "Abrillantador"
    ]
  },
  {
    id: "tools",
    googleEntryId: "entry.1686081750",
    title: "Herramientas y Equipo",
    icon: Wrench,
    options: [
      "Pistolas de pintura",
      "Compresores",
      "Boquillas",
      "Espátulas",
      "Mezcladores"
    ]
  },
  {
    id: "masking",
    googleEntryId: "entry.843992955",
    title: "Masking y Protección",
    icon: Layers,
    options: [
      "Tirro (cinta masking)",
      "Plásticos para cubrir ó plásticos protectores",
      "Papel masking",
      "Trapos",
      "Filtros"
    ]
  },
  {
    id: "ppe",
    googleEntryId: "entry.1096858398",
    title: "Seguridad Industrial (PPE)",
    icon: HardHat,
    options: [
      "Mascarillas",
      "Guantes",
      "Lentes",
      "Overoles"
    ]
  },
  {
    id: "brands",
    googleEntryId: "entry.1602242092",
    title: "Marcas de Preferencia",
    icon: ShieldCheck,
    options: [
      "Axalta",
      "Sherwin-Williams",
      "Jet",
      "Mega",
      "PPG",
      "DuPont",
      "BASF",
      "RM Paint",
      "Glasurit",
      "Sikkens",
      "Nobel"
    ]
  }
];

interface FormSection {
  id: string;
  googleEntryId: string;
  title: string;
  icon: any;
  options: string[];
}

export default function App() {
  const [formData, setFormData] = useState<Record<string, string[]>>({});
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const toggleOption = (sectionId: string, option: string) => {
    setFormData(prev => {
      const current = prev[sectionId] || [];
      if (current.includes(option)) {
        return { ...prev, [sectionId]: current.filter(o => o !== option) };
      } else {
        return { ...prev, [sectionId]: [...current, option] };
      }
    });
  };

  const isSelected = (sectionId: string, option: string) => {
    return formData[sectionId]?.includes(option) || false;
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    // We don't call e.preventDefault() here to let the browser submit to the hidden iframe
    setLoading(true);

    // After a small delay, we show the success message 
    // (since the iframe handles the actual submission in the background)
    setTimeout(() => {
      setLoading(false);
      setSubmitted(true);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 1000);
  };

  const GOOGLE_FORM_URL = "https://docs.google.com/forms/d/e/1FAIpQLSczBOFqvY6FxmlYvF7d-hJOd86pupzzADsmovPr5jgn2mrcwQ/formResponse";

  return (
    <div className="min-h-screen pb-20">
      {/* Hidden iframe to handle Google Form submission without redirecting the user */}
      <iframe name="votar" className="hidden"></iframe>

      {/* Google Forms Purple Top Strip */}
      <div className="h-24 md:h-32 bg-google-purple w-full mb-4 md:mb-8" />
      
      <main className="max-w-[770px] mx-auto px-3 -mt-6 md:-mt-12 relative z-30">
        <AnimatePresence mode="wait">
          {!submitted ? (
            <motion.form 
              action={GOOGLE_FORM_URL}
              target="votar"
              method="POST"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              onSubmit={handleSubmit}
              className="space-y-3"
            >
              {/* Title Card */}
              <div className="bg-white rounded-lg shadow-[0_1px_3px_0_rgba(60,64,67,0.3),0_4px_8px_3px_rgba(60,64,67,0.15)] border border-google-border overflow-hidden">
                <div className="h-[10px] bg-google-purple" />
                <div className="p-6 md:p-8">
                  <h1 className="text-3xl font-normal text-slate-900 mb-4 tracking-normal">AutoPaint Pro</h1>
                  <p className="text-[14px] text-slate-800 leading-relaxed mb-6 whitespace-pre-wrap">
                    Catálogo de Suministros y Equipamiento para Pintura Automotriz.
                    {"\n\n"}
                    Seleccione los productos y marcas que desea cotizar o adquirir. Este formulario será enviado directamente a nuestro equipo técnico.
                  </p>
                  
                  <div className="border-t border-slate-200 pt-6 mt-6">
                    <p className="text-[14px] text-red-600 mb-4">* Indica que la pregunta es obligatoria</p>
                    <div className="space-y-6">
                      <div className="space-y-4">
                        <label className="text-[16px] font-normal text-slate-900 flex items-center">
                          Nombre Completo <span className="text-red-600 ml-1">*</span>
                        </label>
                        <input 
                          required
                          name="nombre"
                          type="text" 
                          placeholder="Tu respuesta"
                          className="w-full md:w-1/2 border-b border-slate-300 py-2 focus:border-google-purple focus:border-b-2 transition-all outline-none text-[14px]"
                        />
                      </div>
                      <div className="space-y-4">
                        <label className="text-[16px] font-normal text-slate-900">
                          Empresa / Taller
                        </label>
                        <input 
                          name="empresa"
                          type="text" 
                          placeholder="Tu respuesta"
                          className="w-full md:w-1/2 border-b border-slate-300 py-2 focus:border-google-purple focus:border-b-2 transition-all outline-none text-[14px]"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Dynamic Sections */}
              {SECTIONS.map((section) => (
                <div
                  key={section.id}
                  className="bg-white rounded-lg shadow-sm border border-google-border p-6 md:p-8"
                >
                  <div className="mb-6">
                    <h3 className="text-[16px] font-normal text-slate-900 mb-1">{section.title}</h3>
                    <p className="text-[12px] text-slate-500">Seleccione todas las que correspondan</p>
                  </div>

                  <div className="grid grid-cols-1 gap-4">
                    {section.options.map((option) => (
                      <label
                        key={option}
                        className="flex items-center gap-3 cursor-pointer group"
                      >
                        <div className="relative flex items-center justify-center">
                          <input
                            name={section.googleEntryId}
                            type="checkbox"
                            value={option}
                            checked={isSelected(section.id, option)}
                            onChange={() => toggleOption(section.id, option)}
                            className="peer appearance-none w-5 h-5 border-2 border-slate-400 rounded transition-all checked:bg-google-purple checked:border-google-purple focus:ring-4 focus:ring-google-purple/10"
                          />
                          <CheckCircle2 className="absolute w-3.5 h-3.5 text-white scale-0 peer-checked:scale-100 transition-transform pointer-events-none" />
                        </div>
                        <span className="text-[14px] text-slate-900 select-none">
                          {option}
                        </span>
                      </label>
                    ))}
                  </div>
                </div>
              ))}

              {/* Submit Area */}
              <div className="flex flex-col md:flex-row justify-between items-center py-4">
                <button
                  type="submit"
                  disabled={loading}
                  className="px-6 py-2 bg-google-purple hover:bg-[#5e35b1] disabled:bg-slate-400 text-white rounded font-medium transition-shadow hover:shadow-md active:bg-[#512da8] text-sm"
                >
                  {loading ? "Enviando..." : "Enviar"}
                </button>
                <div className="mt-4 md:mt-0 flex gap-4">
                  <button 
                    type="button" 
                    onClick={() => { setFormData({}); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                    className="text-google-purple text-sm font-medium hover:bg-google-purple/5 px-2 py-1 rounded"
                  >
                    Borrar formulario
                  </button>
                </div>
              </div>

              <div className="text-center pt-8 pb-12">
                <p className="text-[12px] text-slate-500">Nunca envíes contraseñas a través de Google Forms.</p>
                <p className="text-[12px] text-slate-500 mt-2">Este contenido no ha sido creado ni aprobado por Google.</p>
              </div>
            </motion.form>
          ) : (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-lg shadow-sm border border-google-border overflow-hidden"
            >
              <div className="h-[10px] bg-google-purple" />
              <div className="p-8 md:p-12">
                <h2 className="text-3xl font-normal text-slate-900 mb-4">AutoPaint Pro</h2>
                <p className="text-[14px] text-slate-800 mb-8">Se ha registrado tu respuesta.</p>
                <button
                  onClick={() => { setSubmitted(false); setFormData({}); }}
                  className="text-blue-600 hover:underline text-sm"
                >
                  Enviar otra respuesta
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}
